package com.ssafy.JUNGOL1828;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
	
	static class Refriger implements Comparable<Refriger>{
		int min;
		int max;
		public Refriger(int min, int max) {
			super();
			this.min = min;
			this.max = max;
		}
		@Override
		public int compareTo(Refriger o) {
			int value = this.max - o.max;
			if(value != 0) return value; // 끝 온도가 다르면
			
			//끝 온도가 같으면 낮은 온도 부터
			return this.min-o.min;

		}
		@Override
		public String toString() {
			return "Refriger [min=" + min + ", max=" + max + "]";
		}
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N =sc.nextInt();
		Refriger[] r = new Refriger[N];
		
		for (int i = 0; i < N; i++) {
			r[i] = new Refriger(sc.nextInt(), sc.nextInt());
		}
		
		Arrays.sort(r);

		int count=1;
		int min = r[0].min;
		int max = r[0].max;
		boolean check;
		for (int i = 1; i < N; i++) {
			check = false;
			if(r[i].min<min&&r[i].max>max)
				check=true;
			if(r[i].min>=min&&r[i].min<=max) {
				min = r[i].min;
				check = true;
			}
			if(r[i].max>=min&&r[i].max<=max) {
				min = r[i].max;
				check = true;
			}
			
			if(!check) {
				count++;
				min = r[i].min;
				max = r[i].max;
			}
			
		}
		
		System.out.println(count);
	}
	

}
