package com.ssafy.ws08.step3;

public interface IBookManager {

	void add(Book book);
	
	void saveData();

	void remove(String isbn);

	Book[] getList();

	Book searchByisbn(String isbn) throws ISBNNOtFoundException;

	Book[] searchByTitle(String title);

	Book[] getBooks();

	Book[] getMagazines();

	int getTotalPrice();

	double getPriceAvg();
	
	void sell(String isbn,int quantity) throws ISBNNOtFoundException,QuantityException;
	
	void buy(String isbn,int quantity) throws ISBNNOtFoundException;

}