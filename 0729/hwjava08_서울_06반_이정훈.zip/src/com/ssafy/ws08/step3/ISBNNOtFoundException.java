package com.ssafy.ws08.step3;

public class ISBNNOtFoundException extends Exception	{
	private String isbn;

	public ISBNNOtFoundException(String isbn) {
		super("ISBN에 해당하는 책이 존재하지 않습니다. - "+isbn);
		this.isbn = isbn;
	}

	public String getIsbn() {
		return isbn;
	}
	
	
	
}
