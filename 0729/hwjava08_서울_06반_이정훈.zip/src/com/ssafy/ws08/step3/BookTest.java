package com.ssafy.ws08.step3;


/**
 * BookManager 클래스를 이용하여 도서 객체 추가,삭제,조회하는 클래스
 */
public class BookTest {

    public static void main(String[] args) {
        
        // 도서 리스트를 유지하고 관리하는 BookManager 객체를 생성한다.
        IBookManager bookManager = BookManagerimpl.getInstance();
        // BookManager 객체를 이용해  도서, 잡지 정보를 추가한다.
        
        System.out.println("**********************도서 전체 목록**********************");
        if(bookManager.getList().length==0) {
        	System.out.println("등록된 도서가 없습니다.");
        }
		else {
			for (Book b : bookManager.getList()) {
				System.out.println(b);
			}
		}
        
        
        //bookManager.saveData(); //저장
    }
}