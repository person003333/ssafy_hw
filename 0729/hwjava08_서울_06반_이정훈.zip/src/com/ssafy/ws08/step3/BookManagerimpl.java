package com.ssafy.ws08.step3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;


public class BookManagerimpl implements IBookManager {

	private static Map<String,Book> books = new HashMap<>();
	private static IBookManager instance;
	private static File target = new File("./book.dat");
	private BookManagerimpl() {}

	public static IBookManager getInstance() {
		if(instance == null) {
			instance = new BookManagerimpl();
			loadData();
		}
		return instance;
	}


	@Override
	public void add(Book book) {
		books.put(book.getIsbn(),book);
	}
	
	private static void loadData() {
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(target))){
    		Object readed = ois.readObject();
    		if (readed != null && readed instanceof Map) {
				books = (Map)readed;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}


	@Override
	public void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(target))){
        	oos.writeObject(books);
        	System.out.println("저장 완료!!");
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void remove(String isbn) {
		books.remove(isbn);

		
	}
	
	@Override
	public Book[] getList() {
		return books.values().toArray(new Book[books.size()]);
	}
	
	@Override
	public Book searchByisbn(String isbn) {
		return books.get(isbn);
	}
	
	@Override
	public Book[] searchByTitle(String title) {
		Map<String,Book> result = new HashMap<>();
		for( Map.Entry<String, Book> elem : books.entrySet() ) {
			if(elem.getValue().getTitle().contains(title)) {
				result.put(elem.getKey(), elem.getValue());
			}
		}	
		return result.values().toArray(new Book[result.size()]);
	}
	
	@Override
	public Book[] getBooks() {
		Map<String,Book> result = new HashMap<>();
		for( Map.Entry<String, Book> elem : books.entrySet() ) {
			if(!(elem.getValue() instanceof Magazine)) {
				result.put(elem.getKey(), elem.getValue());
			}
		}	
		return result.values().toArray(new Book[result.size()]);
	}
	
	@Override
	public Book[] getMagazines() {
		Map<String,Book> result = new HashMap<>();
		for( Map.Entry<String, Book> elem : books.entrySet() ) {
			if((elem.getValue() instanceof Magazine)) {
				result.put(elem.getKey(), elem.getValue());
			}
		}	
		return result.values().toArray(new Book[result.size()]);
	}
	
	@Override
	public int getTotalPrice() {
		int totalPrice = 0;
		for( Map.Entry<String, Book> elem : books.entrySet() ) {
			totalPrice +=elem.getValue().getPrice();
		}
		return totalPrice;
	}
	@Override
	public double getPriceAvg() {
		return (double)this.getTotalPrice()/books.size();
	}

	@Override
	public void sell(String isbn, int quantity) throws ISBNNOtFoundException,QuantityException {
		if(books.containsKey(isbn)) {
			if(books.get(isbn).getQuantity()<quantity) {
				throw new QuantityException();
			}
			else {
				books.get(isbn).setQuantity(books.get(isbn).getQuantity()-quantity);
			}
		}
		else{
			throw new ISBNNOtFoundException(isbn);
		}		
	}

	@Override
	public void buy(String isbn, int quantity) throws ISBNNOtFoundException {		
		if(books.containsKey(isbn)) {
			books.get(isbn).setQuantity(books.get(isbn).getQuantity()+quantity);			
		}
		else{
			throw new ISBNNOtFoundException(isbn);
		}		
	}
}
