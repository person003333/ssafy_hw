package com.ssafy.algo;

import java.util.Scanner;
import java.io.FileInputStream;

class Solution {
	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		int T;
		T = sc.nextInt();
		int[][] dir = {{1,0},{0,1},{-1,0},{0,-1}};
		int[][] map;
		for (int test_case = 1; test_case <= T; test_case++) {
			int num = sc.nextInt();
			map = new int[num][num];
			
			int r=0,c=0,d=0;
			int n = 1;
			while(n<=num*num) {
				map[r][c]=n;
				int nr=r+dir[d][1];
				int nc=c+dir[d][0];
				
				if(nr>=num||nr<0||nc>=num||nc<0||map[nr][nc]!=0) {
					d = (d+1)%4;
					
					nr=r+dir[d][1];
					nc=c+dir[d][0];
					
				}
				r=nr;
				c=nc;
				n++;
				
				
			}
			System.out.println("#"+test_case);
			for (int i = 0; i < num; i++) {
				for (int j = 0; j < num; j++) {
					System.out.print(map[i][j]+" ");
				}
				System.out.println();
			}
		}
	}
}