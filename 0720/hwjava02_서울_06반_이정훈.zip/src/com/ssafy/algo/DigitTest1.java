package com.ssafy.algo;

import java.util.Scanner;

public class DigitTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] count = new int[10];
		Scanner sc = new Scanner(System.in);
		
		int num = sc.nextInt();
		while(num != 0) {
			
			count[num/10]++;
			
			num = sc.nextInt();
		}
		
		for (int i = 0; i < count.length; i++) {
			if(count[i]>0) {
				System.out.println(i + " : " + count[i] + "개");
			}
		}
		
		sc.close();
	}

}
