
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.io.FileInputStream;

class Solution1953
{
	static int[][] dir= {{-1,0},{0,1},{1,0},{0,-1}};
	static int[][] pipe = { {}, {0,1,2,3},{0,2},{1,3},
			{0,1},{1,2},{2,3},{3,0}
			
	};
	static int[][] connet = {{1,2,5,6},{1,3,6,7},{1,2,4,7},{1,3,4,5}};
	
	static int N,M,R,C,L;
	static int cnt;
	static int[][] map;
	static boolean[][] check;
	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			N = sc.nextInt();
			M = sc.nextInt();
			R = sc.nextInt()+1;
			C = sc.nextInt()+1;
			L = sc.nextInt();
			cnt = 0;
			map = new int[N+2][M+2];
			check = new boolean[N+2][M+2];
			
			for (int i = 1; i <= N; i++) {
				for (int j = 1; j <= M; j++) {
					map[i][j] = sc.nextInt();
				}
			}
			
//			for (int i = 0; i <= N+1; i++) {
//				for (int j = 0; j <= M+1; j++) {
//					System.out.print(map[i][j]+"\t");
//				}
//				System.out.println();
//			}
			
			bfs();
			System.out.println("#"+test_case+" "+cnt);

		}
	}	
	
	private static void bfs() {
		Queue<Point> points = new LinkedList<Point>();
		points.offer(new Point(R, C, 1,map[R][C]));
		check[R][C]= true; 
		cnt++;
		if(L==1) return;
		while(!points.isEmpty()) {
			Point p = points.poll();
//			System.out.println(p +" " +cnt);
			for (int d = 0; d < pipe[p.n].length; d++) {
				int nr = p.r + dir[pipe[p.n][d]][0];
				int nc = p.c + dir[pipe[p.n][d]][1];
				
				if(!check[nr][nc]) {
					for (int is : connet[pipe[p.n][d]]) {
						if(is == map[nr][nc]) {
							check[nr][nc] = true;
							cnt++;
							if(p.t+1 < L) {
								points.offer(new Point(nr, nc, p.t+1, map[nr][nc]));
							}
							break;
						}
					}
					
				}
			}
		}
	}
	
	private static class Point{
		int r,c,t,n;

		public Point(int r, int c, int t, int n) {
			super();
			this.r = r;
			this.c = c;
			this.t = t;
			this.n = n;
		}

		@Override
		public String toString() {
			return "Point [r=" + r + ", c=" + c + ", t=" + t + ", n=" + n + "]";
		}


		
		
	}
	
}