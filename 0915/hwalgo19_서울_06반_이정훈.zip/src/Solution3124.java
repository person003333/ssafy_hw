import java.util.Arrays;
import java.util.Scanner;
import java.io.FileInputStream;

class Solution3124
{
	static class Edge implements Comparable<Edge>{
		int start,end,weight;

		public Edge(int start, int end, int weight) {
			super();
			this.start = start;
			this.end = end;
			this.weight = weight;
		}

		@Override
		public int compareTo(Edge o) {
			return Integer.compare(this.weight, o.weight);
		}

		@Override
		public String toString() {
			return "Edge [start=" + start + ", end=" + end + ", weight=" + weight + "]";
		}
		
		
	}
	
	static int [] parents;
	static Edge [] edge;

	private static void make() {
		// 모든 원소를 자신을 대표자로 만듦
		for (int i = 0; i < parents.length; i++) {
			parents[i] = i;
		}
	}

	// a가 속한 집합의 대표자 찾기
	private static int find(int a) {
		if (a == parents[a])
			return a;
		return parents[a] = find(parents[a]);
	}

	// 두 원소를 하나의 집합으로 합치기
	private static boolean union(int a, int b) {
		int aRoot = find(a);
		int bRoot = find(b);
		if (aRoot == bRoot)
			return false; // 이미 같은 집합으로 합치지 않음

		parents[bRoot] = aRoot;
		return true;
	}
	
	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		int V,E;
		
		
		for(int test_case = 1; test_case <= T; test_case++)
		{
			V = sc.nextInt();
			E = sc.nextInt();
			
			parents = new int[V+1];
			
			edge = new Edge[E];
			
			for (int i = 0; i < E; i++) {
				int start = sc.nextInt();
				int end = sc.nextInt();
				int weight = sc.nextInt();
				edge[i] = new Edge(start, end, weight);
			}
			
			Arrays.sort(edge);
			
			make();
			
			int cnt = 0;
			long w = 0;
			for (Edge e : edge) {
				if (union(e.start, e.end)) {
					w += e.weight;
					if (++cnt == V - 1)
						break;
				}

			}
			
			System.out.println("#"+test_case+" "+w);
		}
	}
}