package com.ssafy.Class;

public class ProductTest {

	public static void main(String[] args) {
		TV tv = new TV(1,"LG",300000,10,230,"LED");
		Refrigerator rf = new Refrigerator(2, "SamSumg", 500000, 10, 260);
		
		System.out.println(tv);
		System.out.println(rf);

	}

}
