import java.util.Scanner;

class Main15961
{
	
	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		
		int N = sc.nextInt();
		int d = sc.nextInt();
		int k = sc.nextInt();
		int c = sc.nextInt();
		
		int[] arr = new int[N+k];
		int[] check = new int[d+1];
		for (int i = 0; i < N; i++) {
			arr[i] = sc.nextInt();
		}
		for (int i = 0; i < k; i++) {
			arr[N+i] = arr[i];
		}
		int max = 0;
		int count = 0;
		for (int j = 0; j < k; j++) {
			if(check[arr[j]]++ == 0) {
				count++;
			}
		}
		if(check[c]==0) {
			count++;
		}
		max =Math.max(max, count);
		if(check[c]==0) {
			count--;
		}
		int idx = 0;
		for (int i = 0; i < N; i++) {
			if(--check[arr[idx++]] == 0) {
				count--;
			}
			if(check[arr[i+k]]++ == 0) {
				count++;
			}
			if(check[c]==0) {
				count++;
			}
			max =Math.max(max, count);
			if(check[c]==0) {
				count--;
			}
			if(max==k+1) break;
		}
		System.out.println(max);
		sc.close();
		
	}	
	
	
}