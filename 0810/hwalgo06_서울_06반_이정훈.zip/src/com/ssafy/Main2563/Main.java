package com.ssafy.Main2563;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[][] arr = new int[100][100];
		int N = sc.nextInt();
		int r,c;
		for (int i = 0; i < N; i++) {
			r = sc.nextInt();
			c = sc.nextInt();
			
			for (int j = 0; j < 10; j++) {
				for (int j2 = 0; j2 < 10; j2++) {
					arr[r+j][c+j2]++;
				}
			}
		}
		
		int count = 0;
		for (int i = 0; i < 100; i++) {
			for (int j = 0; j < 100; j++) {
				if(arr[i][j]!=0) count++;
			}
		}
		System.out.println(count);

	}

}
