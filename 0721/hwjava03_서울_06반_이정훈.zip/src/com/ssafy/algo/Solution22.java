package com.ssafy.algo;

import java.util.Scanner;

public class Solution22 {
	
	static int N;
	static int[][] map;
	static int[][] del = {{0,0},{-1,0},{1,0},{0,-1},{0,1}};
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int T = sc.nextInt();
		
		for (int t = 0; t < T; t++) {
			N = sc.nextInt();
			map = new int[N][N];
			
			int num = sc.nextInt();
			int[][] salt = new int[num][3];
			
			for (int i = 0; i < num; i++) {
				salt[i][0] = sc.nextInt();		//r 위치
				salt[i][1] = sc.nextInt();		//c 위치
				salt[i][2] = sc.nextInt();		//d 방향
				
				map[salt[i][0]][salt[i][1]]++;
			}
			
			
//			for (int i = 0; i < N; i++) {
//				for (int j = 0; j < N; j++) {
//					System.out.print(map[i][j]+" ");
//				}
//				System.out.println();
//				
//			}
			
			for (int i = 0; i < salt.length; i++) {
				map[salt[i][0]][salt[i][1]]--;
				jump(salt[i][0],salt[i][1],salt[i][2],3);	//점프
			}
			
			int sum=0;
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					sum+=map[i][j];
				}
				
			}
			System.out.println("#"+(t+1)+" "+sum);
			
		}
		
		sc.close();
	}
	
	static void jump(int R, int C, int d,int count) {
		if (count==0) {	//다 뛰었으면 해당 위치에 머무른다.
			map[R][C]++;
		}
		else if(map[R][C] == 0) {	//겹치지 않으면 (겹치면 죽는다.)
			int nr = R+del[d][0]*count;
			int nc = C+del[d][1]*count;
//			System.out.println(nr+" "+nc+" "+d);
			if(nr>=0&&nr<N&&nc>=0&&nc<N&&map[nr][nc]==0) {
				jump(nr,nc,d,--count);	//숫자 줄여서 점프
			}
		}
	}

}
