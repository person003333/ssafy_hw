package com.ssafy.Main1987;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;


public class Main {
	static char[][] arr;
	static boolean[][] check_arr;
	static ArrayList<Character>check = new ArrayList<Character>();
	static int[][] dir = {{1,0},{-1,0},{0,1},{0,-1}};
	static int N,M;
	static int max;
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		N = Integer.parseInt(st.nextToken());
		M = Integer.parseInt(st.nextToken());
		arr = new char[N][M];
		check_arr = new boolean[N][M];
		max=0;

		for (int i = 0; i < N; i++) {
				arr[i]= br.readLine().toCharArray();
		}
		check_arr[0][0]=true;
		check.add(arr[0][0]);
		move(0,0,1);
		
		System.out.println(max);
		
	}
	
	private static void move(int r, int c, int count) {
		max = Math.max(count, max);
		for (int d = 0; d < 4; d++) {
			boolean flag = true;
			int nr = r+dir[d][0];
			int nc = c+dir[d][1];
			if(nr>=0&&nr<N&&nc>=0&&nc<M&&!check_arr[nr][nc]) {
				for (int i = 0; i < check.size(); i++) {
					if(check.get(i)==arr[nr][nc]) {
						flag =false;
						break;
					}
				}
				if(flag) {
					check_arr[nr][nc]=true;
					check.add(arr[nr][nc]);
					move(nr, nc, count+1);
					check_arr[nr][nc] = false;
					check.remove(count);
				}
			}
		}
	}

}
