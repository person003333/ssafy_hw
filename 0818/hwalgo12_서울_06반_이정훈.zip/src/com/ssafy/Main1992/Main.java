package com.ssafy.Main1992;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {
	static int[][] arr;
	static int N;
	static int[] WB;
	static StringBuilder sb = new StringBuilder();
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		N=Integer.parseInt(br.readLine());
		arr = new int[N][N];
		for (int i = 0; i < N; i++) {
			String[] s = br.readLine().split("");
			for (int j = 0; j < N; j++) {
				arr[i][j]=Integer.parseInt(s[j]);
			}	
		}
		
		quarted_tree(0,N,0,N);
		
		System.out.println(sb);
		
	}
	
	public static void quarted_tree(int start_r,int end_r,int start_c,int end_c) {
		int check = arr[start_r][start_c];
		for (int i = start_r; i < end_r; i++) {
			for (int j = start_c; j < end_c; j++) {
				if(arr[i][j]!=check) {
					sb.append('(');
					quarted_tree(start_r,(start_r+end_r)/2,start_c,(start_c+end_c)/2);
					quarted_tree(start_r,(start_r+end_r)/2,(start_c+end_c)/2,end_c);
					quarted_tree((start_r+end_r)/2,end_r,start_c,(start_c+end_c)/2);
					quarted_tree((start_r+end_r)/2,end_r,(start_c+end_c)/2,end_c);
					sb.append(')');
					return;
				}
			}
		}
		sb.append(check);
		
	}

}
