package com.ssafy.Main3040;
import java.util.Scanner;

public class Main {
	
	static int[] arr = new int[9];
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < 9; i++) {
			arr[i] = sc.nextInt();
		}
		
		int N = arr.length;
		int R = 7;

		int[] p = new int[N];
		// 뒤쪽부터 R개 만큼 1 채우기
		int cnt = 0;
		while (++cnt <= R)
			p[N - cnt] = 1;

		do {
			// 조합 사용
			int sum = 0;
			for (int i = 0; i < N; i++) {
				if (p[i] == 1)
					sum+=arr[i];

			}
			if(sum==100) break;
			
		} while (np(p));
		for (int i = 0; i < N; i++) {
			if (p[i] == 1)
				System.out.println(arr[i]);

		}
		
	}

	// 다음 큰 순열이 있으면 true, 없으면 false
	private static boolean np(int[] numbers) {

		int N = numbers.length;

		// step1. 꼭대기(i)를 찾는다. 꼭대기를 통해 교환위치(i-1) 찾기
		int i = N - 1;
		while (i > 0 && numbers[i - 1] >= numbers[i])
			--i;

		if (i == 0)
			return false;

		// step2. i-1 위치값과 교환할 큰 값 찾기
		int j = N - 1;
		while (numbers[i - 1] >= numbers[j])
			--j;

		// step3. i-1 위치값과 j 위치값 교환
		swap(numbers, i - 1, j);
		
		//step4. 꼭대기(i)부터 맨뒤 까지 내림찬순형태의 순열을 오름차순으로 처리
		int k = N -1;
		while(i<k) {
			swap(numbers,i++,k--);
		}
		return true;
	}

	private static void swap(int[] numbers, int i, int j) {
		int temp = numbers[i];
		numbers[i] = numbers[j];
		numbers[j] = temp;
	}
	

}
