import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {

	static int cheese;
	static int last_cheese;
	static int start_r,start_c;
	static int end_r,end_c;
	static int[][] dir = {{1,0},{-1,0},{0,1},{0,-1}};
	static int [][] map;
	static boolean [][] map_check;
	static int time;
	static int N,M;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		M = sc.nextInt();
		map = new int[N][M];
		cheese = 0;
		
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				map[i][j] = sc.nextInt();
				if(map[i][j]==1)
					cheese++;
			}
		}
		
		time = 0;
		end_r = N;
		end_c = M;
		
		melt_cheese();
		
		System.out.println(time);
		System.out.println(last_cheese);
	}
	
	private static void melt_cheese() {
		Queue<Point> point = new LinkedList<Point>();
		
		while(cheese>0) {
			map_check = new boolean[N][M];
			last_cheese = cheese;
			point.offer(new Point(time,time));
			map_check[time][time] = true;
			while(!point.isEmpty()) {
				Point p = point.poll();
				for (int i = 0; i < 4; i++) {
					int nr = p.r + dir[i][0];
					int nc = p.c + dir[i][1];
					if(nr>=time&&nr<end_r && nc>=time&&nc<end_c&&!map_check[nr][nc]) {
						map_check[nr][nc] = true;
						if(map[nr][nc]==1) {
							map[nr][nc]=0;
							cheese--;
						}
						else {
							point.offer(new Point(nr,nc));
						}
					}
				}
				
			}
			time++;
			end_r--;
			end_c--;
				
			
		}
	}
	
	public static class Point{
		int r,c;

		public Point(int r, int c) {
			super();
			this.r = r;
			this.c = c;
		}
		
	}

}
