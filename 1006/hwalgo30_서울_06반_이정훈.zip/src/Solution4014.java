import java.util.Scanner;

public class Solution4014 {
	static int N,X;
	static int[][] map1,map2;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt(); 
		
		
		for (int test_Case = 1; test_Case <= T; test_Case++) {
			N = sc.nextInt();
			X = sc.nextInt();
			
			map1 = new int[N][N];
			map2 = new int[N][N];
			
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					int n = sc.nextInt();
					map1[i][j] = n;
					map2[j][i] = n;
				}
			}
			
			int count = 0;
			
			for (int i = 0; i < N; i++) {
				if(buildOk(map1[i])) count++;
				if(buildOk(map2[i])) count++;
			}
			
			System.out.println("#"+test_Case+" "+count);
		}

	}

	private static boolean buildOk(int[] array) { // 활주로 건설할 가능 체크
		boolean[] check = new boolean[N];
		for (int i = 0; i < N - 1; i++) {
			int prev = array[i];
			int next = array[i + 1];
			if (Math.abs(prev - next) > 1)
				return false; // 2 이상 차이나면 return 0
			if (check[i + 1] || prev == next)
				continue; // 평지거나 이미 지형이 있다면 패스
			if (prev > next) { // 내려갈 때 
				for (int j = i + 1; j <= i + X; j++) { 
					if (j >= N || array[j] != next || check[j])  // n을 넘어가거나, 평지가 아니거나, 이미 지형이 있으면 false
						return false; 
					check[j] = true; // 지형 설치 
				}
			} else { // 올라갈 때 
				for (int j = i; j > i - X; j--) {
					if (j < 0 || array[j] != prev || check[j]) // 0을 넘어가거나, 평지가 아니거나, 이미 지형이 있으면 false
						return false;
					check[j] = true;
				}
			}
		}
		return true;
	}

}
