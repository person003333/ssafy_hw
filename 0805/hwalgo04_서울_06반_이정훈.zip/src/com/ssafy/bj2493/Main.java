package com.ssafy.bj2493;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;
import java.util.StringTokenizer;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int num = Integer.parseInt(br.readLine());
		
		StringTokenizer st = new StringTokenizer(br.readLine());
		Stack<Integer> tower = new Stack<Integer>();
		Stack<Integer> index = new Stack<Integer>();
		
		

		int t;
		tower.push(Integer.parseInt(st.nextToken()));
		index.push(1);
		System.out.print(0 + " ");

		for (int i = 2; i <= num; i++) {
			t = Integer.parseInt(st.nextToken());
			while (!tower.isEmpty()) {
				
				if (tower.peek() > t) {
					System.out.print(index.peek() + " ");
					break;
				}
				else {
					tower.pop();
					index.pop();
				}

			}
			if (tower.isEmpty()) {
				System.out.print(0 + " ");
			}
			tower.push(t);
			index.push(i);

		}
	}

}
