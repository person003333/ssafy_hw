import java.util.Scanner;

public class Main1149 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int [][] arr = new int[N][3];
		int [][] RGB = new int[N][3];
		for (int i = 0; i < arr.length; i++) {			
				arr[i][0] = sc.nextInt();
				arr[i][1] = sc.nextInt();
				arr[i][2] = sc.nextInt();		
		}
		
		RGB[0] = arr[0].clone();
		
		for (int i = 1; i < RGB.length; i++) {
			for (int j = 0; j < 3; j++) {
				RGB[i][j] = Math.min(RGB[i-1][(j+1)%3], RGB[i-1][(j+2)%3])+arr[i][j];
			}
		}
		
		int min=Integer.MAX_VALUE;
		for (int j = 0; j < 3; j++) {
			min = Math.min(RGB[N-1][j], min);
		}
		
		System.out.println(min);
		
	}

}
