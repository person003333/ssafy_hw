import java.util.Scanner;

public class Main {
	static int N;
	static int min;
	static int[][] arr;
	static boolean [] check;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		arr = new int[N][N];
		check = new boolean[N];
		min = Integer.MAX_VALUE;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				arr[i][j] = sc.nextInt();
			}
		}
		check[0] = true;
		dfs(0,0,0);
		System.out.println(min);
	}
	
	private static void dfs(int cnt, int n, int route) {
		if(cnt==N-1) {
			if(arr[n][0]!=0)
				min = Math.min(min, route+arr[n][0]);
			return;
		}
		if(route>min) {
			return;
		}
		for (int i = 1; i < arr.length; i++) {
			if(!check[i]&&arr[n][i]!=0) {
				check[i] = true;
				dfs(cnt+1,i, route+arr[n][i]);
				check[i] = false;
			}
		}
	}

}
