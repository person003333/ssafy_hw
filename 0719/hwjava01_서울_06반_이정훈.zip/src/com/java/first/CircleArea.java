package com.java.first;

public class CircleArea {
	public static void main(String[] args) {
		int r = 5;
		
		System.out.println("반지름이 "+r+"Cm인 원의 넓이는 "+(r*r*3.14)+"Cm2입니다.");
	}

}
