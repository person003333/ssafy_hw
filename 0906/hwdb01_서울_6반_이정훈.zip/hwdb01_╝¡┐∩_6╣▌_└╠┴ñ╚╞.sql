-- 1 상품정보를 저장하는 테이블 구성 (상품코드, 상품며, 상품 가격 등)
CREATE TABLE Product(
	pcode int(4) PRIMARY KEY,
    pname VARCHAR(10),
    price int(10)
);

-- desc Product;

-- 2. 상품 데이터를 5개 이상 저장하는 SQL
INSERT INTO Product VALUES (11,'삼성 노트북',1000000);
INSERT INTO Product VALUES (12,'LG 노트북',850000);
INSERT INTO Product VALUES (13,'MS 노트북',900000);
INSERT INTO Product VALUES (14,'lenovo 노트북',500000);
INSERT INTO Product VALUES (21,'LG TV',2500000);
INSERT INTO Product VALUES (22,'LG LED TV',2700000);
INSERT INTO Product VALUES (23,'삼성 TV',3100000);
INSERT INTO Product VALUES (24,'디스플레이 TV',3500000);


-- select * from Product;

-- 3. 상품을 세일하려고 한다. 15% 인하된 가격의 상품정보를 출력하세요
select pcode, pname, floor(price*(1-0.15)) 할인가격
from Product;

-- 4. TV 관련 상품을 가격을 20% 안허허요 저장하세요.
update Product
set price = price*0.8
where pname like '%TV';

-- select * from Product;

-- 5. 저장된 상품의 총합을 출력하세요
select sum(price) "상품 총합"
from Product;