import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.PriorityBlockingQueue;
import java.io.FileInputStream;

class Solution
{
	
	static class Vertex implements Comparable<Vertex>{
		int no;
		long distance;

		public Vertex(int no, long distance) {
			super();
			this.no = no;
			this.distance = distance;
		}

		@Override
		public int compareTo(Vertex o) {
			return Long.compare(this.distance, o.distance);
		}
		
		
	}
	
	static int N;
	static double E;
	static long[][] arr;
	static long[] distance;
	static boolean[] check;
	static long min;
	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			N = sc.nextInt();
			arr = new long[N][2];
			check = new boolean[N];
			distance = new long[N];
			min = 0;
			
			int start = 0;
			for (int i = 0; i < N; i++) {
				arr[i][0] = sc.nextInt();
			}
			for (int i = 0; i < N; i++) {
				arr[i][1] = sc.nextInt();
			}
			E = sc.nextDouble();
			Arrays.fill(distance, Long.MAX_VALUE);
			distance[start] = 0; // 시각점 0의 간선 비용을 0으로
			
			
			PriorityBlockingQueue<Vertex> pq = new PriorityBlockingQueue<Vertex>();
			pq.offer(new Vertex(start,distance[start]));
			
			while(!pq.isEmpty()) {
				Vertex current = pq.poll();
				check[current.no] = true;
				
				for (int j = 0; j < N; j++) {
					if(!check[j]&&distance[j]>(Math.pow(arr[current.no][0]-arr[j][0],2)+Math.pow(arr[current.no][1]-arr[j][1],2))) {
						distance[j]=(long)(Math.pow(arr[current.no][0]-arr[j][0],2)+Math.pow(arr[current.no][1]-arr[j][1],2));
						pq.offer(new Vertex(j,distance[j]));
					}
					
				}
				
			}
			for (int i = 0; i < N; i++) {
				min+=distance[i];
			}
			System.out.println("#"+test_case+" "+Math.round((min)*E));
			

		}
	}

}