package com.ssafy.Main17406;
import java.util.Scanner;

public class Main {
	static int N, M, R;
	static int[][] arr;
	static int[][] arr_main;
	static int[][] rcs;
	static boolean[] rcs_check;
	static int[] numbers;
	static int min, sum;
	static int[][] dir = { { 0, 1 }, { 1, 0 }, { 0, -1 }, { -1, 0 } };

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		N = sc.nextInt();
		M = sc.nextInt();
		R = sc.nextInt();
		min = Integer.MAX_VALUE;
		numbers = new int[R];
		arr_main = new int[N][M];
		arr = new int[N][M];
		rcs = new int[R][3];
		rcs_check = new boolean[R];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				arr_main[i][j] = sc.nextInt();
			}
		}

		for (int a = 0; a < R; a++) {
			rcs[a][0] = sc.nextInt() - 1;
			rcs[a][1] = sc.nextInt() - 1;
			rcs[a][2] = sc.nextInt();
		}

		permutation(0);

		System.out.println(min);

		sc.close();

	}

	private static void permutation(int cnt) {
		if (cnt == R) {

			for (int i = 0; i < N; i++) {
				for (int j = 0; j < M; j++) {
					arr[i][j] = arr_main[i][j];
				}
			}

			for (int n : numbers) {
				turn(rcs[n][0] - rcs[n][2], rcs[n][1] - rcs[n][2], rcs[n][0] + rcs[n][2], rcs[n][1] + rcs[n][2]);
			}
			for (int i = 0; i < N; i++) {
				sum = 0;
				for (int j = 0; j < M; j++) {
					sum += arr[i][j];
				}

				min = Math.min(sum, min);
			}

			return;
		}
		for (int i = 0; i < R; i++) {
			if (rcs_check[i])
				continue;

			numbers[cnt] = i;
			rcs_check[i] = true;

			permutation(cnt + 1);
			rcs_check[i] = false;
		}
	}

	public static void turn(int start_i, int start_j, int end_i, int end_j) {
		int temp1, temp2;
		int i = start_i;
		int j = start_j;
		int n_i, n_j;
		int d = 0;
		temp1 = arr[i][j];
		i = i + dir[d][0];
		j = j + dir[d][1];
		while (i != start_i || j != start_j) {
			temp2 = arr[i][j];
			arr[i][j] = temp1;
			temp1 = temp2;

			n_i = i + dir[d][0];
			n_j = j + dir[d][1];

			if (n_i >= start_i && n_i <= end_i && n_j >= start_j && n_j <= end_j) {
				i = n_i;
				j = n_j;
			} else {
				d++;
				i = i + dir[d][0];
				j = j + dir[d][1];
			}

		}
		arr[i][j] = temp1;

		if ((end_i - start_i) > 2 && (end_j - start_j) > 2) {
			turn(start_i + 1, start_j + 1, end_i - 1, end_j - 1);
		}

	}

}