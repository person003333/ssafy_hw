import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileInputStream;

class Solution1767
{
	static int[][] dir = {{-1,0},{0,1},{1,0},{0,-1}};
	static int N;
	static int[][] arr;
	
	static int min_line;
	static int connect;
	static ArrayList<Point> cores;
	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		for(int test_case = 1; test_case <= T; test_case++)
		{
			N = sc.nextInt();
			arr = new int[N][N];
			
			min_line = Integer.MAX_VALUE;
			connect = 0;
			
			cores = new ArrayList<Point>();
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					arr[i][j] = sc.nextInt();
					if(arr[i][j]==1) {
						if(i==0||j==0||i==N-1||j==N-1) {
							connect++;
						}
						else {
							cores.add(new Point(i,j));
						}
					}
				}
			}
			
			dfs(0, connect, 0);
			System.out.println("#"+test_case+" "+min_line);
			
		}
	}
	
	private static void dfs(int core, int c,int line) {
		if(core==cores.size()) {
			if(c>connect) {
				connect = c;
				min_line = line;
			}
			else if(c==connect && line < min_line) {
				min_line = line;
			}
			return;
		}
		Point p = cores.get(core);
		for (int i = 0; i < 4; i++) {
			if(isconnect(p.r, p.c, i)) {
				int l = fill(p.r, p.c, i, 2);
				dfs(core+1, c+1, line+l);
				fill(p.r, p.c, i, 0);
			}
		}
		dfs(core+1, c, line);
		
	}
	private static boolean isconnect(int r,int c,int d) {
		int nr = r+ dir[d][0];
		int nc = c+ dir[d][1];
		while(nr>=0&&nr<N&&nc>=0&&nc<N) {
			if(arr[nr][nc]>0) {
				return false;
			}
			nr = nr + dir[d][0];
			nc = nc + dir[d][1];
		}
		return true;
	}
	
	private static int fill(int r,int c,int d,int num) {
		int count = 0;
		int nr = r+ dir[d][0];
		int nc = c+ dir[d][1];
		while(nr>=0&&nr<N&&nc>=0&&nc<N) {
			arr[nr][nc]=num;
			count++;
			nr = nr + dir[d][0];
			nc = nc + dir[d][1];
		}
		return count;
		
	}
	private static class Point{
		int r,c;

		public Point(int r, int c) {
			super();
			this.r = r;
			this.c = c;
		}
		
	}
}
