package com.ssafy.Solution9229;

import java.util.Scanner;
import java.io.FileInputStream;

class Solution {
	static int max_weight;
	static int N, M;
	static int[] arr;

	public static void choose(int w, int start,int count) {
		if(count==2) {
			max_weight = Math.max(w, max_weight);
			return;
		}	
		for (int i = start; i < N; i++) {
			if (w + arr[i] <= M)
				choose(w + arr[i], i + 1,count+1);
		}

	}

	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		int T;
		T = sc.nextInt();

		for (int test_case = 1; test_case <= T; test_case++) {
			max_weight = -1;
			N = sc.nextInt();
			M = sc.nextInt();
			arr = new int[N];

			for (int i = 0; i < arr.length; i++) {
				arr[i] = sc.nextInt();
			}

			choose(0, 0,0);

			System.out.println("#" + test_case + " " + max_weight);
		}
	}
}