import java.util.Scanner;
import java.io.FileInputStream;

class Solution {

	static int N, M;
	static int group; // 그룹 수
	static int[] parents; // 부모원소를 관리(트리 처럼 관리);

	private static void make() {
		group = N;	
		parents = new int[N+1];
		// 모든 원소를 자신을 대표자로 만듦
		for (int i = 0; i < N; i++) {
			parents[i] = i;
		}
	}

	// a가 속한 집합의 대표자 찾기
	private static int find(int a) {
		if (a == parents[a])
			return a;
		return parents[a] = find(parents[a]);
	}

	// 두 원소를 하나의 집합으로 합치기
	private static boolean union(int a, int b) {
		int aRoot = find(a);
		int bRoot = find(b);
		if (aRoot == bRoot)
			return false; // 이미 같은 집합으로 합치지 않음

		parents[bRoot] = aRoot;
		group--;
		return true;
	}

	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		int T;
		T = sc.nextInt();

		for (int test_case = 1; test_case <= T; test_case++) {
			N = sc.nextInt();
			M = sc.nextInt();
			make();
			
			for (int i = 0; i < M; i++) {
				union(sc.nextInt(),sc.nextInt());
			}
			
			System.out.println("#"+test_case+" "+group);

		}

		sc.close();
	}
}