import java.util.Scanner;
import java.io.FileInputStream;

class Solution
{
	static int N;
	static int[] arr;
	static boolean[] check;
	static int left,right;
	static int count;
	static int number[];
	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		
		for(int test_case = 1; test_case <= T; test_case++)
		{
			N = sc.nextInt();
			left = 0;
			right = 0;
			count=0;
			arr= new int[N];
			check = new boolean[N];
			number = new int[N];
			for (int i = 0; i < N; i++) {
				arr[i] = sc.nextInt();
			}
			scale(0);
			System.out.println("#"+test_case+" "+count);

		}
	}
	
	
	private static void scale(int cnt) {
		if(cnt==N) {
			left_right(0);
			return;
		}
		for (int i = 0; i < N; i++) {
			if(!check[i]) {
				check[i]=true;
				number[cnt]=arr[i];
				scale(cnt+1);
				check[i]=false;
			}
		}
	}
	
	private static void left_right(int cnt) {
		if(cnt==N) {
			count++;
			return;
		}
		int n = number[cnt];
		left+=n;
		left_right(cnt+1);
		left-=n;
		if(left>=right+n) {
			right+=n;
			left_right(cnt+1);
			right-=n;
		}
	}
}