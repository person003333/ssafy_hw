
import java.util.Scanner;
import java.io.FileInputStream;

class Solution5643
{
	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			int M = sc.nextInt();
			
			int[][] taller = new int[N+1][N+1];
			
			int[] t = new int[N+1];
			for (int i = 0; i < M; i++) {
				int a = sc.nextInt();
				int b = sc.nextInt();
				taller[a][b] = 1;
			}
			
			for (int k = 1; k <= N; k++) {
				for (int i = 1; i <= N; i++) {
					if(k==i) continue;
					for (int j = 1; j <= N; j++) {
						if(j==k||j==i) continue;
						if(taller[i][k]==1 && taller[k][j]==1) {
							taller[i][j] =1;
						}
	
					}
				}
			}
			int cnt =0;
			for (int i = 1; i <= N; i++) {
				for (int j = 1; j <= N; j++) {
					if(taller[i][j]==1) {
						t[i]++;
						t[j]++;
					}
				}
			}
			for (int i = 1; i <= N; i++) {
				if(t[i]==N-1) {
					cnt++;
				}
			}
			System.out.println("#"+test_case+" "+cnt);

		}
	}	
	
	
}