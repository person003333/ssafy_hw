package com.ssafy.Class;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;




public class ProductMgr implements IProductMgr {
	

	private HashMap<Integer, Product> product = new HashMap<>();
	@Override
	public void add(Product p) {	//상품 추가
		product.put(p.getNum(), p);
	}
	
	
	@Override
	public Product[] getList() {	// 상품 전체 리스트
		return product.values().toArray(new Product[product.size()]);
	}
	
	@Override
	public Product searchBynum(int n) {	//상품번호로 검색
		return product.get(n);
	}
	
	@Override
	public Product[] searchByName(String name) {//상품명으로 검색(부분검색)

		List<Product> result = new ArrayList<Product>();
		for (Product p : product.values()) {
			if(p.getName().contains(name)) {
				result.add(p);
			}
		}
		return result.toArray(new Product[result.size()]);
	}
	
	@Override
	public Product[] getTV() {	// TV 정보
		List<Product> result = new ArrayList<Product>();
		for (Product p : product.values()) {
			if(!(p instanceof Refrigerator)) {
				result.add(p);
			}
		}
		return result.toArray(new Product[result.size()]);
	}
	
	@Override
	public Product[] getRefrigerator() { // 냉장고 정보
		List<Product> result = new ArrayList<Product>();
		for (Product p : product.values()) {
			if(p instanceof Refrigerator) {
				result.add(p);
			}
		}
		return result.toArray(new Product[result.size()]);
	}
	
	@Override
	public Product[] getTV_50inch() { //50인치 이상 TV
		List<Product> TV = Arrays.asList(this.getTV());
		List<Product> result = new ArrayList<Product>();
		for (Product p : TV) {
			if(((TV)p).getInchi()>=50) {
				result.add(p);
			}
		}
		return result.toArray(new Product[result.size()]);
	}
	
	@Override
	public Product[] getRefrigerator_400L() { //400L이상 냉장고
		List<Product> Refrigerator = Arrays.asList(this.getRefrigerator());
		List<Product> result = new ArrayList<Product>();
		for (Product p : Refrigerator) {
			if(((Refrigerator)p).getLiter()>=400) {
				result.add(p);
			}
		}
		return result.toArray(new Product[result.size()]);
	}
	
	@Override
	public void change(int n, int price) { //제품 가격변경
		product.get(n).setPrice(price);
	}
	
	@Override
	public void remove(int n) {	//상품 번호로 삭제
		product.remove(n);		
	}
	@Override
	public int getTotalPrice() {	//전체 재고 상품 금액 (재고*가격)
		int totalPrice = 0;

		for (Product p : product.values()) {
			if(p instanceof Refrigerator) {
				totalPrice += p.getPrice()*p.getAmong();
			}
		}
		return totalPrice;
	}


}
