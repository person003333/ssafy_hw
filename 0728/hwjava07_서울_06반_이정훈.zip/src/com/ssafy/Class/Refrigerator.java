package com.ssafy.Class;

public class Refrigerator extends Product{
	
	private  int Liter;

	public Refrigerator(int num, String name, int price, int among, int liter) {
		super(num, name, price, among);
		Liter = liter;
	}

	public int getLiter() {
		return Liter;
	}

	public void setLiter(int liter) {
		Liter = liter;
	}

	@Override
	public String toString() {
		return super.toString() + ", 용량="+Liter;
	}
	
	
}
