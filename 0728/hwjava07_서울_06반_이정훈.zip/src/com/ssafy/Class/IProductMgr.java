package com.ssafy.Class;

public interface IProductMgr {

	void add(Product p);

	Product[] getList();

	Product searchBynum(int n);

	Product[] searchByName(String name);

	Product[] getTV();

	Product[] getRefrigerator();
	
	Product[] getTV_50inch();

	Product[] getRefrigerator_400L();

	void change(int n, int price);
	
	void remove(int n);

	int getTotalPrice();

}