package com.ssafy.Class;


public class ProdcutTest {

	public static void main(String[] args) {
		ProductMgr pm = new ProductMgr();
		
		pm.add(new TV(10,"LG 디스플레이",300000,5,230,"OLED"));
		pm.add(new TV(11,"삼성 디스플레이",260000,6,230,"나노셀"));
		pm.add(new TV(12,"이노스 디스플레이",220000,10,230,"QLED"));
		pm.add(new TV(13,"더함 디스플레이",230000,3,230,"LED"));
		pm.add(new Refrigerator(21, "삼성 냉장고", 650000, 1, 780));
		pm.add(new Refrigerator(22, "LG 냉장고", 630000, 6, 860));
		pm.add(new Refrigerator(23, "대우 냉장고", 550000, 5, 880));
		pm.add(new Refrigerator(24, "비스포크 냉장고", 530000, 7, 790));
		
		System.out.println("**********************상품 전체 목록**********************");
        for (Product p : pm.getList()) {
            System.out.println(p);
        }
        System.out.println("**********************TV 목록**********************");
        for (Product p : pm.getTV()) {
            System.out.println(p);
        }
        System.out.println("**********************냉장고 목록**********************");
        for (Product p : pm.getRefrigerator()) {
            System.out.println(p);
        }
        System.out.println("**********************상품번호 검색:10**********************");
        
        System.out.println(pm.searchBynum(10));
        
        System.out.println("**********************상품정보 포함검색:삼성**********************");
        for (Product p : pm.searchByName("삼성")) {
            System.out.println(p);
        }
        
        System.out.println("**********************전체 재고**********************");
        System.out.println("전체 재고 가격 총합 : "+pm.getTotalPrice()+"원");

	}

}
