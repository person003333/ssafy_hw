package com.ssafy.Class;

public class TV extends Product{
	
	private int inchi;
	private String type;
	
	public TV(int num, String name, int price, int among, int inchi, String type) {
		super(num, name, price, among);
		this.inchi = inchi;
		this.type = type;
	}
	
	
	public int getInchi() {
		return inchi;
	}


	public void setInchi(int inchi) {
		this.inchi = inchi;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	@Override
	public String toString() {
		return super.toString() + ", 인치=" + inchi + ", 타입=" + type;
	}
	
	

	
}
