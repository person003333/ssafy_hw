package com.ssafy.Class;


import java.util.Arrays;



public class ProductMgr {
	
	static private final int MAX_SIZE = 100;;
	private Product[] product = new Product[MAX_SIZE];
	private int size = 0;
	
	public void add(Product p) {	//상품 추가
		if(size<MAX_SIZE) product[size++] = p;
	}
	
	
	public Product[] getList() {	// 상품 전체 리스트
		return Arrays.copyOfRange(product, 0, size);
	}
	
	public Product searchBynum(int n) {	//상품번호로 검색
		for (int i = 0; i < size; i++) {
			if(product[i].getNum()==n) {
				return product[i];
			}
		}
		return null;
	}
	
	public Product[] searchByName(String name) {//상품명으로 검색(부분검색)
		int count=0;
		for (int i = 0; i < size; i++) {
			if(product[i].getName().contains(name)) {
				count++;
			}
		}
		Product[] result = new Product[count];
		int index = 0;
		for (int i = 0; i < size; i++) {
			if(product[i].getName().contains(name)) {
				result[index++]=product[i];
			}
		}
		
		return result;
	}
	
	public Product[] getTV() {	// TV 정보
		int count=0;
		for (int i = 0; i < size; i++) {
			if(product[i] instanceof TV) {
				count++;
			}
		}
		Product[] result = new Product[count];
		int index = 0;
		for (int i = 0; i < size; i++) {
			if(product[i] instanceof TV) {
				result[index++]=product[i];
			}
		}
				
		return result;
	}
	
	public Product[] getRefrigerator() { // 냉장고 정보
		int count=0;
		for (int i = 0; i < size; i++) {
			if(product[i] instanceof Refrigerator) {
				count++;
			}
		}
		Product[] result = new Product[count];
		int index = 0;
		for (int i = 0; i < size; i++) {
			if(product[i] instanceof Refrigerator) {
				result[index++]=product[i];
			}
		}
				
		return result;
	}
	
	public void remove(int n) {	//상품 번호로 삭제
		for (int i = 0; i < size; i++) {
			if(product[i].getNum() == n) {
				product[i] = product[size-1];
				product[size-1]=null;
				size--;
				break;
			}
		}
		
	}
	public int getTotalPrice() {	//전체 재고 상품 금액 (재고*가격)
		int totalPrice = 0;
		for (int i = 0; i < size; i++) {
			totalPrice += product[i].getPrice() * product[i].getAmong();
		}
		return totalPrice;
	}


}
