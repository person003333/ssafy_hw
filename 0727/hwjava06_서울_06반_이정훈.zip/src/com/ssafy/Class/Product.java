package com.ssafy.Class;

public class Product {
	private int num;
	private String name;
	private int price;
	private int among;
	
	public Product(int num, String name, int price, int among) {
		this.num = num;
		this.name = name;
		this.price = price;
		this.among = among;
	}
	
	
	public int getNum() {
		return num;
	}


	public void setNum(int num) {
		this.num = num;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public int getAmong() {
		return among;
	}


	public void setAmong(int among) {
		this.among = among;
	}


	@Override
	public String toString() {
		return "제품번호=" + num + ", 제품명=" + name + ", 가격=" + price + ", 재고수량=" + among;
	}
	
	
}
